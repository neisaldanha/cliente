@extends('layouts.admin')

@section('conteudo')

<section>
    {{ Form::model( ['method' => 'POST','route'=>'cad-cliente.store', 'id' => 'cliente', 'class' => 'cadastro', 'files' => true]) }}
        
        <div class="col-12">
            <button type="submit" class="btn btn-secondary my-2 mr-1" title="Salvar"><i class="fas fa-save"></i></button>
            <a href="#" class="btn btn-secondary my-2 mr-1" title="Excluir"><i class="fas fa-trash"></i></a>
            <a href="#" class="btn btn-secondary my-2 mr-1" title="Imprimir"><i class="fas fa-print"></i></a>
            <a href="#" class="btn btn-secondary my-2 mr-1" title="Simular Preço"><i class="fas fa-calculator"></i></a>
            <a href="#" class="btn btn-secondary my-2 mr-1" title="Histórico de Compras"><i class="fas fa-truck"></i></a>
            <a href="#" class="btn btn-secondary my-2 mr-1" title="Histórico de Vendas"><i class="fas fa-cart-arrow-down"></i></a>
        </div>

    <!-- Informações Gerais -->
    
        <h4>Informações Gerais</h4>
        <div class="form-group">
            {!! Form::label('TIPO', 'Tipo', ['class' => 'fw-5 mb-1']) !!}
            {!! Form::select('TIPO',['F'=>'Fisica','J'=>'Juridica'], null,array( 'class' => 'form-group cpf_cnpj', 'autocomplete' => 'off')) !!}
        </div>

        <div class="form-group"></div>
        <div class="row" id="fisica">
            <div class="form-group col-md-4">
                {!! Form::label('CPF', 'CPF', ['class' => 'fw-5 mb-1']) !!}
                {!! Form::text('CPF', null, array('required','id'=>'CPF', 'class' => 'form-control ', 'placeholder' => 'Somente Nº', 'autocomplete' => 'off')) !!}
            </div>
            <div class="form-group col-md-6">
                {!! Form::label('NOME', 'Nome', ['class' => 'fw-5 mb-1']) !!}
                {!! Form::text('NOME', null, array('required', 'class' => 'form-control', 'placeholder' => 'Nome completo', 'autocomplete' => 'off')) !!}
            </div>
            <div class="form-group col-md-4">
                {!! Form::label('DT_NASCIMENTO', 'Nascimento', ['class' => 'fw-5 mb-1']) !!}
                {!! Form::date('DT_NASCIMENTO', null, array('required', 'class' => 'form-control', 'placeholder' => 'Número do RG', 'autocomplete' => 'off')) !!}
            </div>
            <div class="form-group col-md-6">
                {!! Form::label('APELIDO', 'Como prefere ser chamado', ['class' => 'fw-5 mb-1']) !!}
                {!! Form::text('APELIDO', null, array('class' => 'form-control', 'placeholder' => 'Nome de preferência', 'autocomplete' => 'off')) !!}
            </div>
        </div>
        <div class="form-group"></div>
        <div style="display:none;" class="row" id="juridica">
            <div class="form-group col-md-3">
                {!! Form::label('CPF_CNPJ', 'CNPJ', ['class' => 'fw-5 mb-1']) !!}
                {!! Form::text('CPF_CNPJ', null, array('id'=>'CNPJ', 'class' => 'form-control cpf_cnpj', 'placeholder' => 'Somente Nº', 'autocomplete' => 'off')) !!}
            </div>
            <div class="form-group col-md-6">
                {!! Form::label('DES_NOME', 'Fantasia', ['class' => 'fw-5 mb-1']) !!}
                {!! Form::text('DES_NOME', null, array('class' => 'form-control', 'placeholder' => 'Nome completo', 'autocomplete' => 'off')) !!}
            </div>
            <div class="form-group col-md-6">
                {!! Form::label('DES_RAZAO', 'Razão Social', ['class' => 'fw-5 mb-1']) !!}
                {!! Form::text('DES_RAZAO', null, array('class' => 'form-control', 'placeholder' => 'Nome de preferência', 'autocomplete' => 'off')) !!}
            </div>
        </div>
        <h4>Contato</h4>
        <div class="form-group"></div>
        <div class="row">
            <div class="form-group col-md-3">
                {!! Form::label('CTT_FONE', 'Fone', ['class' => 'fw-5 mb-1']) !!}
                {!! Form::text('CTT_FONE', null, array('required', 'class' => 'form-control', 'placeholder' => 'Telefone Fixo', 'autocomplete' => 'off')) !!}
            </div>                                
            <div class="form-group col-md-3">
                {!! Form::label('CTT_CELULAR', 'Celular', ['class' => 'fw-5 mb-1']) !!}
                {!! Form::text('CTT_CELULAR', null, array('required', 'class' => 'form-control', 'placeholder' => 'Celular', 'autocomplete' => 'off')) !!}
            </div>                                
            <div class="form-group col-md-6">
                {!! Form::label('CTT_EMAIL', 'E-Mail', ['class' => 'fw-5 mb-1']) !!}
                {!! Form::text('CTT_EMAIL', null, array('required','class' => 'form-control', 'placeholder' => 'exemplo@exemplo.com', 'autocomplete' => 'off')) !!}
            </div>
        </div>
        <div class="form-group"></div>
        <h4>Endereço</h4>
        <div class="row">
           
            <div class="form-group col-sm-4"> 
                {!! Form::label('CEP', 'CEP') !!}
                {!! Form::text('CEP', null, array('required','placeholder' => 'CEP', "maxlength" => "9", 'onblur' => "pesquisacep(this.value);", 'class' => 'form-control', 'autocomplete' => 'off')) !!}
            </div>
            <div class="form-group col-sm-2"> 
                {!! Form::label('ESTADO', 'UF') !!}
                {!! Form::text('ESTADO', null, array('required','placeholder' => 'UF', 'class' => 'form-control', 'autocomplete' => 'off')) !!}
            </div>
            <div class="form-group col-sm-4"> 
                {!! Form::label('CIDADE', 'Cidade') !!}
                {!! Form::text('CIDADE', null, array('required','placeholder' => 'Cidade', 'class' => 'form-control', 'autocomplete' => 'off')) !!}
            </div>
            <div class="form-group col-sm-4"> 
                {!! Form::label('END_BAIRRO', 'Bairro') !!}
                {!! Form::text('END_BAIRRO', null, array('required','placeholder' => 'Bairro', 'class' => 'form-control', 'autocomplete' => 'off')) !!}
            </div>
            <div class="form-group col-sm-4"> 
                {!! Form::label('END_LOGRADOURO', 'Logradouro') !!}
                {!! Form::text('END_LOGRADOURO', null, array('required','placeholder' => 'Logradouro', 'class' => 'form-control', 'autocomplete' => 'off')) !!}
            </div>
            <div class="form-group col-sm-4"> 
                {!! Form::label('NUMERO', 'Número') !!}
                {!! Form::text('NUMERO', null, array('required','placeholder' => 'Numero', 'class' => 'form-control', 'autocomplete' => 'off')) !!}
            </div>
            <div class="form-group col-sm-12"> 
                {!! Form::label('REF', 'Referência') !!}
                {!! Form::text('REF', null, array('class' => 'form-control', 'placeholder' => 'Nome da Empresa', 'autocomplete' => 'off')) !!}
            </div>
        </div>
    {{ Form::close() }}
</section>

@stop
   
@section('scripts')
    
    
@endsection